package dto;

public class Task_TeamDto 
{
	private String Team_id;
	private String Task_id;
	private String Skill;
	 
	public Task_TeamDto(String Team_id, String Task_id, String Skill) 
	{
		this.Team_id = Team_id;
		this.Task_id = Task_id;
		this.Skill = Skill;
	}
	public String getTask_id() {
	  return Task_id;
	}
	public void setTask_id(String Task_id) {
	  this.Task_id = Task_id;
	  }
	public String getSkill() {
	  return Skill;
	}
	public void setSkill(String Skill) {
	  this.Skill = Skill;
	}
	public String getTeam_id() {
		return Team_id;
	}
	public void setTeam_id(String team_id) {
		Team_id = team_id;
	}
	
}
