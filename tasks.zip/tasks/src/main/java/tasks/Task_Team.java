package tasks;


import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.sql.*; 

import dto.Task_TeamDto;

public class Task_Team extends Thread
{
	final File folder = new File("C:/csv_files");
	List<String> filenames = new LinkedList<String>();
	static Logger logger = Logger.getLogger("MyLog");  
	static FileHandler fh;
	
	static String Team_id="";
	static String Task_id="";
	static String Skill="";
	static int flag=0; //means false
	
	@Override
	public void run() 
	{	
		logger.info("Task_Team - START "+"Thread ID: "+ Thread.currentThread().getId() +" Thread Name: "+Thread.currentThread().getName());
		Thread t= Thread.currentThread();
		
		try {
            Thread.sleep(1000);
        
            if(folder.listFiles().length == 0)
            {
            	throw new Exception("There is no file in this folder: " + folder);
            }
            else
            {
            	for (final File fileEntry : folder.listFiles()) 
	            {
	    	        if (fileEntry.isDirectory()) {
	    	        	logger.info("Do nothing as of now...");
	    	        } 
	    	        else if(fileEntry.getName().contains(".csv"))
	    	        {
    	                filenames.add(fileEntry.getName());
    	                logger.info("Get into here now : " + fileEntry.getName() + "Thread ID: "+ Thread.currentThread().getId() +" Thread Name: "+Thread.currentThread().getName());
    		            
    		            callingCSVFile(fileEntry);
	    	        }
	    	        else
	    	        {
	    	        	throw new Exception("There is no file in this folder: " + folder);
	    	        }
	    	    }
            	
            }
            
            if(flag==1)
            {
            	logger.info("Data Loading is Completed...");
            	logger.info("Start to assigning task");
            	retrieveDBValue();
            }
            
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        catch(Exception e)
        {
        	logger.info(e.getMessage());
        }
       
		logger.info(" - END  " + " Thread ID: "+ t.getId() +" Thread Name: "+t.getName());
	}

	
	public void callingCSVFile(final File folder) 
	{
		readCsvFile(folder);
	}
	
	
	private synchronized void readCsvFile(File csvFile) {
	    BufferedReader reader =
	        null;

	    try {

	        Class.forName("com.mysql.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/TM", "root", "");

	        List < Task_TeamDto > users = new ArrayList < Task_TeamDto > ();
	        String line = "";

	        reader = new BufferedReader(new FileReader(csvFile));
	        reader.readLine();

	        if (csvFile.getName().equalsIgnoreCase("task.csv")) {
	            while ((line =
	                    reader.readLine()) != null) {
	                String[] fields = line.split(",");

	                if (fields.length > 0) {
	                    Task_TeamDto user = new Task_TeamDto(Team_id,Task_id,Skill);
	                    user.setTask_id(fields[0].trim());
	                    user.setSkill(fields[1].trim());
	                    users.add(user);

	                    System.out.printf(user.getTask_id() + " " + user.getSkill());
	                }
	            }
	        } else
	        if (csvFile.getName().equalsIgnoreCase("team_skill.csv")) {
	            while ((line =
	                    reader.readLine()) != null) {
	                String[] fields = line.split(",");

	                if (fields.length > 0) {
	                    Task_TeamDto user = new Task_TeamDto(Team_id,Task_id,Skill);
	                    user.setTeam_id(fields[0].trim());
	                    user.setSkill(fields[1].trim());
	                    users.add(user);

	                    System.out.printf(user.getTeam_id() + " " + user.getSkill());
	                }
	            }
	        } else
	        if (csvFile.getName().equalsIgnoreCase("team.csv")) {
	            while ((line =
	                    reader.readLine()) != null) {
	                String[] fields = line.split(",");

	                if (fields.length > 0) {
	                    Task_TeamDto user = new Task_TeamDto(Team_id,Task_id,Skill);
	                    user.setTeam_id(fields[0].trim());
	                    users.add(user);

	                    System.out.printf(user.getTeam_id());
	                }
	            }
	        }


	        for (Task_TeamDto task: users) {
	            logger.info("Inserting value into DB now...");
	            String sql = "";
	            PreparedStatement ps = null;

	            if (csvFile.getName().equalsIgnoreCase("task.csv")) {
	                sql = "INSERT INTO TASK(TASK_ID,SKILL)VALUES(?,?)";
	                ps =
	                    con.prepareStatement(sql);
	                ps.setString(1, task.getTask_id());
	                ps.setString(2, task.getSkill());
	                reader.close();
	                if (csvFile.delete()) {
	                    logger.info("Success Deleting the " + csvFile.getName());
	                } else {
	                    logger.info("Failed Deleting the " + csvFile.getName());
	                }
	            } else
	            if (csvFile.getName().equalsIgnoreCase("team_skill.csv")) {
	                sql = "INSERT INTO TEAM_SKILL(TEAM_ID,SKILL)VALUES(?,?)";
	                ps =
	                    con.prepareStatement(sql);
	                ps.setString(1, task.getTeam_id());
	                ps.setString(2, task.getSkill());
	                reader.close();
	                if (csvFile.delete()) {
	                    logger.info("Success Deleting the " + csvFile.getName());
	                } else {
	                    logger.info("Failed Deleting the " + csvFile.getName());
	                }
	            } else
	            if (csvFile.getName().equalsIgnoreCase("team.csv")) {
	                sql = "INSERT INTO TEAM(TEAM_ID)VALUES(?)";
	                ps = con.prepareStatement(sql);
	                ps.setString(1, task.getTeam_id());
	                reader.close();
	                if (csvFile.delete()) {
	                    logger.info("Success Deleting the " + csvFile.getName());
	                } else {
	                    logger.info("Failed Deleting the " + csvFile.getName());
	                }
	            }

	            flag = ps.executeUpdate();
	            ps.close();
	        }



	    } catch (Exception ex) {
	        ex.printStackTrace();
	    } finally {
	        try {
	            reader.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
	 
	
	public static void retrieveDBValue() throws ClassNotFoundException, SQLException
	{		
		List<Task_TeamDto> team_01 = new ArrayList<>();
		List<Task_TeamDto> team_02 = new ArrayList<>();
		List<Task_TeamDto> team_03 = new ArrayList<>();
		List<Task_TeamDto> team_04 = new ArrayList<>();
		List<Task_TeamDto> team_05 = new ArrayList<>();
		
		Task_TeamDto task_team = new Task_TeamDto(Team_id,Task_id,Skill);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TM","root","");  
			Statement e = con.createStatement();
			ResultSet rs = e.executeQuery("SELECT A.TEAM_ID as TEAM_ID,B.SKILL,C.TASK_ID \r\n" + 
					"FROM team A \r\n" + 
					"LEFT JOIN team_skill B \r\n" + 
					"ON A.TEAM_ID = B.TEAM_ID \r\n" + 
					"LEFT JOIN task C \r\n" + 
					"ON B.SKILL = C.SKILL \r\n" + 
					"ORDER BY TEAM_ID,SKILL;");
			
			
			while (rs.next()) 
			{	
				task_team.setTeam_id(rs.getString("TEAM_ID").replace("\"", ""));
				task_team.setSkill(rs.getString("SKILL").replace("\"", ""));
				task_team.setTask_id(rs.getString("TASK_ID").replace("\"", ""));
				
				if(task_team.getTeam_id().replace("\"", "").equalsIgnoreCase("TEAM_01"))
				{
					if(team_01.size() == 6)
					{
						logger.info("TEAM_01 has reach 6 task! Proceed to the TEAM_02 ");
					}
					else
					{
						team_01.add(new Task_TeamDto(task_team.getTeam_id(),task_team.getSkill(),task_team.getTask_id()));
					}
					
				}
				if(task_team.getTeam_id().replace("\"", "").equalsIgnoreCase("TEAM_02"))
				{
					if(team_02.size() == 6)
					{
						logger.info("TEAM_02 has reach 6 task! Proceed to the TEAM_03 ");
					}
					else
					{
						team_02.add(new Task_TeamDto(task_team.getTeam_id(),task_team.getSkill(),task_team.getTask_id()));
					}
					
				}
				if(task_team.getTeam_id().replace("\"", "").equalsIgnoreCase("TEAM_03"))
				{
					if(team_03.size() == 6)
					{
						logger.info("TEAM_03 has reach 6 task! Proceed to the TEAM_04 ");
					}
					else
					{
						team_03.add(new Task_TeamDto(task_team.getTeam_id(),task_team.getSkill(),task_team.getTask_id()));
					}
					
				}
				if(task_team.getTeam_id().replace("\"", "").equalsIgnoreCase("TEAM_04"))
				{
					if(team_04.size() == 6)
					{
						logger.info("TEAM_04 has reach 6 task! Proceed to the TEAM_05 ");
					}
					else
					{
						team_04.add(new Task_TeamDto(task_team.getTeam_id(),task_team.getSkill(),task_team.getTask_id()));
					}
					
				}
				if(task_team.getTeam_id().replace("\"", "").equalsIgnoreCase("TEAM_05"))
				{
					if(team_05.size() == 6)
					{
						logger.info("TEAM_05 has reach 6 task! Proceed to the TEAM_06 ");
					}
					else
					{
						team_05.add(new Task_TeamDto(task_team.getTeam_id(),task_team.getSkill(),task_team.getTask_id()));
					}
					
				}
			}
				
			rs.close();
			e.close();
		} catch (SQLException arg3) {
			arg3.printStackTrace();
			logger.info("error: " + arg3.getMessage());
		}
		
		
		for(Task_TeamDto t : team_01)
		{
			logger.info(t.getTeam_id()+" "+t.getSkill()+" "+t.getTask_id());
		}
		for(Task_TeamDto t : team_02)
		{
			logger.info(t.getTeam_id()+" "+t.getSkill()+" "+t.getTask_id());
		}
		for(Task_TeamDto t : team_03)
		{
			logger.info(t.getTeam_id()+" "+t.getSkill()+" "+t.getTask_id());
		}
		for(Task_TeamDto t : team_04)
		{
			logger.info(t.getTeam_id()+" "+t.getSkill()+" "+t.getTask_id());
		}
		for(Task_TeamDto t : team_05)
		{
			logger.info(t.getTeam_id()+" "+t.getSkill()+" "+t.getTask_id());
		}
		logger.info("Tasks Assigned!");
		logger.info("Start to save the Assignment Result into Database now...");
		
		String sql = "";
        PreparedStatement ps = null;
		if(flag == 1)
		{
	        Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TM","root","");  
			
			for(Task_TeamDto t : team_01)
			{
		        sql = "INSERT INTO ASSIGNMENT_RESULT(TEAM_ID,SKILL,TASK_ID)VALUES(?,?,?)";
		        ps = con.prepareStatement(sql);
		        ps.setString(1, t.getTeam_id());
		        ps.setString(2, t.getSkill());
		        ps.setString(3, t.getTask_id());
		        
		        flag = ps.executeUpdate();
		        ps.close();
	        }
			
			for(Task_TeamDto t : team_02)
			{
		        sql = "INSERT INTO ASSIGNMENT_RESULT(TEAM_ID,SKILL,TASK_ID)VALUES(?,?,?)";
		        ps = con.prepareStatement(sql);
		        ps.setString(1, t.getTeam_id());
		        ps.setString(2, t.getSkill());
		        ps.setString(3, t.getTask_id());
		        
		        flag = ps.executeUpdate();
		        ps.close();
	        }
			
			for(Task_TeamDto t : team_03)
			{
		        sql = "INSERT INTO ASSIGNMENT_RESULT(TEAM_ID,SKILL,TASK_ID)VALUES(?,?,?)";
		        ps = con.prepareStatement(sql);
		        ps.setString(1, t.getTeam_id());
		        ps.setString(2, t.getSkill());
		        ps.setString(3, t.getTask_id());
		        
		        flag = ps.executeUpdate();
		        ps.close();
	        }
			
			for(Task_TeamDto t : team_04)
			{
		        sql = "INSERT INTO ASSIGNMENT_RESULT(TEAM_ID,SKILL,TASK_ID)VALUES(?,?,?)";
		        ps = con.prepareStatement(sql);
		        ps.setString(1, t.getTeam_id());
		        ps.setString(2, t.getSkill());
		        ps.setString(3, t.getTask_id());
		        
		        flag = ps.executeUpdate();
		        ps.close();
	        }
			
			for(Task_TeamDto t : team_05)
			{
		        sql = "INSERT INTO ASSIGNMENT_RESULT(TEAM_ID,SKILL,TASK_ID)VALUES(?,?,?)";
		        ps = con.prepareStatement(sql);
		        ps.setString(1, t.getTeam_id());
		        ps.setString(2, t.getSkill());
		        ps.setString(3, t.getTask_id());
		        
		        flag = ps.executeUpdate();
		        ps.close();
	        }
		}
        
        if(flag ==1)
        {
        	logger.info("Task Assigned Successfully Saved into Database...");
        }
		
	}
	
	public static void main(String[] args) throws InterruptedException, ClassNotFoundException, SQLException 
	{ 
	  //Thread initialization
	  Task_Team mythread = new Task_Team();
	  Thread t1 = new Thread(mythread);
	  t1.start();
	  
	  //logger handler [START]
	  try 
	  {  

	        // This block configure the logger with handler and formatter  
	        fh = new FileHandler("C:/TM_Log/MyLogFile.log");  
	       
	        logger.addHandler(fh);
	        SimpleFormatter formatter = new SimpleFormatter();  
	        fh.setFormatter(formatter);  

	        // the following statement is used to log any messages  
	        logger.info("Thread ID: " + t1.getId() + " " + "Thread Name : " +t1.getName());

	  } 
	  catch (SecurityException e) 
	  {  
		  e.printStackTrace();  
	  } 
	  catch (IOException e) 
	  {  
		  e.printStackTrace();  
	  }
	  //logger handler [END]
	}
}
	
	 

	


